﻿namespace MyCouch.Testing.Model
{
    public class Album
    {
        public string Name { get; set; }
    }
}