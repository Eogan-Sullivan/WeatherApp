﻿
namespace MyCouch
{
    internal static class FormatStrings
    {
        internal const string JsonPropertyAppendFormat = ",\"{0}\": {1}";
        internal const string JsonPropertyFormat = "\"{0}\": {1}";
    }
}
