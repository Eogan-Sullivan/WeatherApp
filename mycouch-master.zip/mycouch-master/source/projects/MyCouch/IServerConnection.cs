﻿namespace MyCouch
{
    public interface IServerConnection : IConnection { }
}