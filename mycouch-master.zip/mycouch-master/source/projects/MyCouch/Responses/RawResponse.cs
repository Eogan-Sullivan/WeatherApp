﻿namespace MyCouch.Responses
{
    public class RawResponse : TextResponse { }
}