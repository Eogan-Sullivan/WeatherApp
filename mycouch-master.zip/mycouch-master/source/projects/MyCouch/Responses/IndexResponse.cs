﻿namespace MyCouch.Responses
{
    public class IndexResponse : Response
    {
        public string Result { get; set; }
    }
}
