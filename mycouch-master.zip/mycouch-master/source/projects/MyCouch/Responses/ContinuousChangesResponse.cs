﻿namespace MyCouch.Responses
{
    public class ContinuousChangesResponse : Response { }
}