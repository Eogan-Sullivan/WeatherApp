﻿namespace MyCouch.Responses
{
    public class DatabaseHeaderResponse : Response
    {
        public string DbName { get; set; }
    }
}