﻿namespace MyCouch.Requests
{
    public abstract class Request { }
}